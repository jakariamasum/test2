import { isValidObjectId } from "mongoose";
import { TUser } from "./user.interface";
import { User } from "./user.model";

const createUserIntoDB = async (payload: TUser) => {
  const result = await User.create(payload);
  return result;
};

const getAllUserFromDB = async () => {
  const result = await User.find();
  return result;
};
const getSingleUserFromDB = async (email: string) => {
  const result = await User.findOne({ email: email });
  return result;
};

const updateUserIntoDB = async (id: string, payload: Partial<TUser>) => {
  const result = await User.findByIdAndUpdate({ _id: id }, payload, {
    new: true,
  });
  return result;
};

const deleteUserFromDB = async (id: string) => {
  const result = await User.findByIdAndDelete({ _id: id });
  return result;
};

const loginUserFromDB = async (email: string, password: string) => {
  console.log(email, password);
  const user = await User.login(email, password);
  return user;
};

export const userServices = {
  createUserIntoDB,
  getSingleUserFromDB,
  getAllUserFromDB,
  updateUserIntoDB,
  deleteUserFromDB,
  loginUserFromDB,
};
