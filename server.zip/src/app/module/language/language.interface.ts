export type TLanguage = {
  title: string;
  language_code: string;
  language_type: "0" | "1";
  link: string;
};
