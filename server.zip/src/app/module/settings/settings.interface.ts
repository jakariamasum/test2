export type TSettings = {
  site_name: string;
  site_description?: string;
  contact_email: string;
  twitter?: string;
  facebook?: string;
  linkedin?: string;
};
