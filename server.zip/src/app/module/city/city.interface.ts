type TCity = {
  title: string;
};
